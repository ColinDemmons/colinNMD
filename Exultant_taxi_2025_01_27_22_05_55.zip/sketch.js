function setup() {
  createCanvas(800, 800);
}

function draw() {
  background(220);
  fill("rgb(93,93,216)")
  rect(0,0,800,800)
  fill("tan")
  rect(00,450,800,800)
  fill("silver")
  ellipse(300,200,230,150)
  fill("blue")
  ellipse(370,200,50,50)
  fill("black")
  ellipse (370,200,30,30)
  fill("red")
  triangle(189,200,90,65,120,360)
}